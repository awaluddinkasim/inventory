<div class="table-responsive text-nowrap">
    <table class="table table-hover">
        <?php echo e($slot); ?>

    </table>
</div>
<?php /**PATH D:\Data\laragon\Web\inventory\resources\views/components/component/table.blade.php ENDPATH**/ ?>