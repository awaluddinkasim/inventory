    <?php
        $__scriptKey = '52596734-0';
        ob_start();
    ?>
    <script>
        $wire.on('open-modal', () => {
            $('#editModal').modal('show');
        })
    </script>
    <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>

<div>
    <?php if (isset($component)) { $__componentOriginal37e1d73a67025cec33503ee0e13dec3c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal37e1d73a67025cec33503ee0e13dec3c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.component.table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('component.table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <thead>
            <th>#</th>
            <th>MFG</th>
            <th>Name</th>
            <th></th>
        </thead>
        <tbody>
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($type->mfg); ?></td>
                    <td><?php echo e($type->name); ?></td>

                    <td class="text-center">
                        <button type="button" class="btn btn-primary btn-sm" wire:click="edit(<?php echo e($type->id); ?>)"
                            wire:loading.attr="disabled">
                            Edit
                        </button>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $type)): ?>
                            <form action="<?php echo e(route('master.type.destroy', $type->id)); ?>" class="d-inline" method="POST">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <?php if (isset($component)) { $__componentOriginal5fdb3ddb6f48af634ffa7876751c05ce = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5fdb3ddb6f48af634ffa7876751c05ce = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.component.button','data' => ['type' => 'submit','label' => 'Delete','color' => 'danger','small' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('component.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','label' => 'Delete','color' => 'danger','small' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5fdb3ddb6f48af634ffa7876751c05ce)): ?>
<?php $attributes = $__attributesOriginal5fdb3ddb6f48af634ffa7876751c05ce; ?>
<?php unset($__attributesOriginal5fdb3ddb6f48af634ffa7876751c05ce); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5fdb3ddb6f48af634ffa7876751c05ce)): ?>
<?php $component = $__componentOriginal5fdb3ddb6f48af634ffa7876751c05ce; ?>
<?php unset($__componentOriginal5fdb3ddb6f48af634ffa7876751c05ce); ?>
<?php endif; ?>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="text-center text-muted">No Data Available</td>
                </tr>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </tbody>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal37e1d73a67025cec33503ee0e13dec3c)): ?>
<?php $attributes = $__attributesOriginal37e1d73a67025cec33503ee0e13dec3c; ?>
<?php unset($__attributesOriginal37e1d73a67025cec33503ee0e13dec3c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal37e1d73a67025cec33503ee0e13dec3c)): ?>
<?php $component = $__componentOriginal37e1d73a67025cec33503ee0e13dec3c; ?>
<?php unset($__componentOriginal37e1d73a67025cec33503ee0e13dec3c); ?>
<?php endif; ?>

    <div class="mt-3">
        <?php echo e($types->links()); ?>

    </div>

    <?php if (isset($component)) { $__componentOriginal7d7f880f3601fc91ee8071cbd41ca624 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d7f880f3601fc91ee8071cbd41ca624 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.component.modal','data' => ['id' => 'editModal','title' => 'Edit Data']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('component.modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'editModal','title' => 'Edit Data']); ?>
        <form action="<?php if($currentEdit): ?> <?php echo e(route('master.type.update', $currentEdit->id)); ?> <?php endif; ?>"
            method="POST" autocomplete="off">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <div class="modal-body">
                <?php if (isset($component)) { $__componentOriginaldab510762a7038f405ecef85d75dbcb5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldab510762a7038f405ecef85d75dbcb5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.datalist','data' => ['label' => 'MFG','name' => 'mfg','id' => 'mfgInput','value' => $currentEdit?->mfg,'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.datalist'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'MFG','name' => 'mfg','id' => 'mfgInput','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($currentEdit?->mfg),'required' => true]); ?>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $mfgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mfg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($mfg); ?>"><?php echo e($mfg); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldab510762a7038f405ecef85d75dbcb5)): ?>
<?php $attributes = $__attributesOriginaldab510762a7038f405ecef85d75dbcb5; ?>
<?php unset($__attributesOriginaldab510762a7038f405ecef85d75dbcb5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldab510762a7038f405ecef85d75dbcb5)): ?>
<?php $component = $__componentOriginaldab510762a7038f405ecef85d75dbcb5; ?>
<?php unset($__componentOriginaldab510762a7038f405ecef85d75dbcb5); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['label' => 'Name','name' => 'name','id' => 'nameInput','value' => $currentEdit?->name,'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Name','name' => 'name','id' => 'nameInput','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($currentEdit?->name),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $attributes = $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $component = $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Close
                </button>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </form>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d7f880f3601fc91ee8071cbd41ca624)): ?>
<?php $attributes = $__attributesOriginal7d7f880f3601fc91ee8071cbd41ca624; ?>
<?php unset($__attributesOriginal7d7f880f3601fc91ee8071cbd41ca624); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d7f880f3601fc91ee8071cbd41ca624)): ?>
<?php $component = $__componentOriginal7d7f880f3601fc91ee8071cbd41ca624; ?>
<?php unset($__componentOriginal7d7f880f3601fc91ee8071cbd41ca624); ?>
<?php endif; ?>
</div>
<?php /**PATH D:\Data\laragon\Web\inventory\resources\views/livewire/grip-type.blade.php ENDPATH**/ ?>