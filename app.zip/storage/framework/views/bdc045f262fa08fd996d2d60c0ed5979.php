<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'label',
    'type' => 'button',
    'color' => 'primary',
    'icon' => 'bx-circle',
    'small' => false,
    'href' => null,
    'disabled' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'label',
    'type' => 'button',
    'color' => 'primary',
    'icon' => 'bx-circle',
    'small' => false,
    'href' => null,
    'disabled' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<button type="<?php echo e($type); ?>" class="btn btn-<?php echo e($color); ?> <?php if($small): ?> btn-sm <?php endif; ?>"
    <?php if($href): ?> onclick="document.location.href='<?php echo e($href); ?>'" <?php endif; ?>
    <?php if($disabled): ?> disabled <?php endif; ?> <?php echo e($attributes); ?>>
    <span class="tf-icons bx <?php echo e($icon); ?>"></span>&nbsp;<span><?php echo e($label); ?></span>
</button>
<?php /**PATH D:\Data\laragon\Web\inventory\resources\views/components/component/button-icon.blade.php ENDPATH**/ ?>