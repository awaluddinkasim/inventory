<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'Grip Detail']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Grip Detail']); ?>
    <div class="row">
        <div class="col-lg-5">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title">Grip Model Type</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <h5 class="mb-0">MFG</h5>
                        <p><?php echo e($grip->model->type->mfg); ?></p>
                    </div>
                    <div class="mb-3">
                        <h5 class="mb-0">Type</h5>
                        <p><?php echo e($grip->model->type->name); ?></p>
                    </div>
                    <div class="mb-3">
                        <h5 class="mb-0">Model</h5>
                        <p><?php echo e($grip->model->name); ?></p>
                    </div>
                    <div class="mb-3">
                        <h5 class="mb-0">Link</h5>
                        <p>
                            <?php if($grip->model->url): ?>
                                <a href="<?php echo e($grip->model->url); ?>" target="_blank"><?php echo e($grip->model->url); ?></a>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-7">
            <div class="card my-2 my-md-0">
                <div class="card-header">
                    <h5 class="card-title">Grip Detail</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <h5 class="mb-0">Size</h5>
                                <p><?php echo e($grip->size); ?></p>
                            </div>
                            <div class="mb-3">
                                <h5 class="mb-0">Color</h5>
                                <p><?php echo e($grip->color); ?></p>
                            </div>
                            <div class="mb-3">
                                <h5 class="mb-0">Weight</h5>
                                <p><?php echo e($grip->weight); ?></p>
                            </div>
                            <div class="mb-3">
                                <h5 class="mb-0">Core Size</h5>
                                <p><?php echo e($grip->core_size); ?></p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <h5 class="mb-0">Wholesale Price</h5>
                                <p>Rp. <?php echo e(number_format($grip->wholesale)); ?></p>
                            </div>
                            <div class="mb-3">
                                <h5 class="mb-0">Retail Percentage</h5>
                                <p><?php echo e(number_format($grip->percent)); ?>%</p>
                            </div>
                            <div class="mb-3">
                                <h5 class="mb-0">Retail Price</h5>
                                <p>Rp. <?php echo e(number_format($grip->retail)); ?></p>
                            </div>
                            <div class="mb-3">
                                <h5 class="mb-0">Stock</h5>
                                <p><?php echo e($grip->stock->sum('quantity')); ?></p>
                            </div>
                        </div>
                        <div class="text-end">
                            <?php if (isset($component)) { $__componentOriginal699799b83eff1107e56b6a6b62885174 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal699799b83eff1107e56b6a6b62885174 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.component.button-icon','data' => ['icon' => 'bx-edit','label' => 'Edit','color' => 'primary','href' => ''.e(route('grips.edit', $grip)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('component.button-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bx-edit','label' => 'Edit','color' => 'primary','href' => ''.e(route('grips.edit', $grip)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal699799b83eff1107e56b6a6b62885174)): ?>
<?php $attributes = $__attributesOriginal699799b83eff1107e56b6a6b62885174; ?>
<?php unset($__attributesOriginal699799b83eff1107e56b6a6b62885174); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal699799b83eff1107e56b6a6b62885174)): ?>
<?php $component = $__componentOriginal699799b83eff1107e56b6a6b62885174; ?>
<?php unset($__componentOriginal699799b83eff1107e56b6a6b62885174); ?>
<?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $grip)): ?>
                                <form action="<?php echo e(route('grips.destroy', $grip)); ?>" method="post" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <?php if (isset($component)) { $__componentOriginal699799b83eff1107e56b6a6b62885174 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal699799b83eff1107e56b6a6b62885174 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.component.button-icon','data' => ['icon' => 'bx-trash','label' => 'Delete','color' => 'danger','type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('component.button-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bx-trash','label' => 'Delete','color' => 'danger','type' => 'submit']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal699799b83eff1107e56b6a6b62885174)): ?>
<?php $attributes = $__attributesOriginal699799b83eff1107e56b6a6b62885174; ?>
<?php unset($__attributesOriginal699799b83eff1107e56b6a6b62885174); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal699799b83eff1107e56b6a6b62885174)): ?>
<?php $component = $__componentOriginal699799b83eff1107e56b6a6b62885174; ?>
<?php unset($__componentOriginal699799b83eff1107e56b6a6b62885174); ?>
<?php endif; ?>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\Data\laragon\Web\inventory\resources\views/pages/grip/show.blade.php ENDPATH**/ ?>