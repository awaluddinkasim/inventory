<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['id']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['id']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/datatables/datatables.min.css')); ?>" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/libs/datatables/datatables.min.js')); ?>"></script>
    <script>
        let table = new DataTable('#<?php echo e($id); ?>', {
            sort: false,
        });
    </script>
<?php $__env->stopPush(); ?>

<div class="table-responsive text-nowrap pb-3">
    <table id="<?php echo e($id); ?>" class="table table-hover">
        <?php echo e($slot); ?>

    </table>
</div>
<?php /**PATH D:\Data\laragon\Web\inventory\resources\views/components/component/datatable.blade.php ENDPATH**/ ?>