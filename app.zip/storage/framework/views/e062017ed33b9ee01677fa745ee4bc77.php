<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'Stock']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Stock']); ?>
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <h5 class="card-title">Stock</h5>
                <div class="me-lg-5">
                    <span>Grand Total</span>
                    <h4>Rp. <?php echo e(number_format($grips->sum('amount'))); ?></h4>
                </div>
            </div>
        </div>
        <div class="card-body">
            <?php if (isset($component)) { $__componentOriginal60afcd9de3ae73d82743a34dad7a3f27 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal60afcd9de3ae73d82743a34dad7a3f27 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.component.datatable','data' => ['id' => 'stockTable']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('component.datatable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'stockTable']); ?>
                <thead>
                    <th>#</th>
                    <th>Grip Model</th>
                    <th>Size</th>
                    <th>Color</th>
                    <th>Wholesale Price</th>
                    <th>Quantity</th>
                    <th>Amount</th>
                    <th></th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $grips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <?php if($grip->model->url): ?>
                                    <a href="<?php echo e($grip->model->url); ?>" target="_blank">
                                        <?php echo e($grip->model->name); ?>

                                    </a>
                                <?php else: ?>
                                    <?php echo e($grip->model->name); ?>

                                <?php endif; ?>
                            </td>
                            <td><?php echo e($grip->size); ?></td>
                            <td><?php echo e($grip->color); ?></td>
                            <td>Rp. <?php echo e(number_format($grip->wholesale)); ?></td>
                            <td><?php echo e($grip->stock->sum('quantity')); ?></td>
                            <td>Rp. <?php echo e(number_format($grip->stock->sum('amount'))); ?></td>

                            <td class="text-center">
                                <?php if (isset($component)) { $__componentOriginal699799b83eff1107e56b6a6b62885174 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal699799b83eff1107e56b6a6b62885174 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.component.button-icon','data' => ['label' => 'Show','color' => 'primary','icon' => 'bx-show','href' => ''.e(route('stock.show', $grip->id)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('component.button-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Show','color' => 'primary','icon' => 'bx-show','href' => ''.e(route('stock.show', $grip->id)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal699799b83eff1107e56b6a6b62885174)): ?>
<?php $attributes = $__attributesOriginal699799b83eff1107e56b6a6b62885174; ?>
<?php unset($__attributesOriginal699799b83eff1107e56b6a6b62885174); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal699799b83eff1107e56b6a6b62885174)): ?>
<?php $component = $__componentOriginal699799b83eff1107e56b6a6b62885174; ?>
<?php unset($__componentOriginal699799b83eff1107e56b6a6b62885174); ?>
<?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal60afcd9de3ae73d82743a34dad7a3f27)): ?>
<?php $attributes = $__attributesOriginal60afcd9de3ae73d82743a34dad7a3f27; ?>
<?php unset($__attributesOriginal60afcd9de3ae73d82743a34dad7a3f27); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal60afcd9de3ae73d82743a34dad7a3f27)): ?>
<?php $component = $__componentOriginal60afcd9de3ae73d82743a34dad7a3f27; ?>
<?php unset($__componentOriginal60afcd9de3ae73d82743a34dad7a3f27); ?>
<?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\Data\laragon\Web\inventory\resources\views/pages/stock/index.blade.php ENDPATH**/ ?>