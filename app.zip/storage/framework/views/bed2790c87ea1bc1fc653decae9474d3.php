<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'label',
    'type' => 'text',
    'id',
    'name',
    'required' => false,
    'readonly' => false,
    'isNumeric' => false,
    'value' => null,
    'helperText' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'label',
    'type' => 'text',
    'id',
    'name',
    'required' => false,
    'readonly' => false,
    'isNumeric' => false,
    'value' => null,
    'helperText' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>


<?php $__env->startPush('scripts'); ?>
    <?php if($isNumeric): ?>
        <script src="<?php echo e(asset('assets/libs/autonumeric/autoNumeric.min.js')); ?>"></script>
        <script>
            new AutoNumeric('#<?php echo e($id); ?>', {
                allowDecimalPadding: false,
                modifyValueOnWheel: false
            });
        </script>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<div class="mb-3">
    <label class="form-label" for="<?php echo e($id); ?>"><?php echo e($label); ?></label>
    <input type="<?php echo e($type); ?>" name="<?php echo e($name); ?>" value="<?php echo e($value); ?>"
        class="form-control <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="<?php echo e($id); ?>"
        <?php if($readonly): ?> readonly <?php endif; ?> <?php if($required): ?> required <?php endif; ?>
        <?php echo e($attributes); ?>>
    <?php if($helperText): ?>
        <small class="text-muted"><?php echo e($helperText); ?></small>
    <?php endif; ?>
</div>
<?php /**PATH D:\Data\laragon\Web\inventory\resources\views/components/form/input.blade.php ENDPATH**/ ?>