<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title', 'action', 'label']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title', 'action', 'label']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#formModal">
    <?php echo e($label); ?>

</button>

<!-- Modal -->
<?php if (isset($component)) { $__componentOriginal7d7f880f3601fc91ee8071cbd41ca624 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d7f880f3601fc91ee8071cbd41ca624 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.component.modal','data' => ['id' => 'formModal','title' => $title]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('component.modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'formModal','title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title)]); ?>
    <form action="<?php echo e($action); ?>" method="POST" autocomplete="off">
        <?php echo csrf_field(); ?>
        <div class="modal-body">
            <?php echo e($slot); ?>

        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                Close
            </button>
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d7f880f3601fc91ee8071cbd41ca624)): ?>
<?php $attributes = $__attributesOriginal7d7f880f3601fc91ee8071cbd41ca624; ?>
<?php unset($__attributesOriginal7d7f880f3601fc91ee8071cbd41ca624); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d7f880f3601fc91ee8071cbd41ca624)): ?>
<?php $component = $__componentOriginal7d7f880f3601fc91ee8071cbd41ca624; ?>
<?php unset($__componentOriginal7d7f880f3601fc91ee8071cbd41ca624); ?>
<?php endif; ?>
<?php /**PATH D:\Data\laragon\Web\inventory\resources\views/components/form/modal.blade.php ENDPATH**/ ?>