<x-layout title="Barcode">
    <livewire:grip-barcode />
</x-layout>
