<div class="table-responsive text-nowrap">
    <table class="table table-hover">
        {{ $slot }}
    </table>
</div>
